package Git::LoadCPAN::Mail::Address;
use 5.008;
use strict;
use warnings $ENV{GIT_PERL_FATAL_WARNINGS} ? qw(FATAL all) : ();
use Git::LoadCPAN (
	module => 'Mail::Address',
	import => 0,
);

1;
